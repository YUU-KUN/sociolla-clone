<template>
  <div>
      <h1>HALO INI HALAMAN PRODUCT</h1>
  </div>
</template>

<script>
// import Product from '../components/ProductComponent.vue'
export default {

}
</script>

<style>

</style>