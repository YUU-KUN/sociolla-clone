<template>
  <h1>
      SHIPPING PAGE IS ON PROGRESS
  </h1>
</template>

<script>
export default {

}
</script>

<style>

</style>