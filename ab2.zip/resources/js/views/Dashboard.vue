<template>
  <div>
      <!-- Preloader -->
	<!-- <div class="preloader">
		<div class="preloader-inner">
			<div class="preloader-icon">
				<span></span>
				<span></span>
			</div>
		</div>
	</div> -->
	<!-- End Preloader -->


	<!-- Header -->

	<!-- Slider Area -->

	<!-- Start Small Banner  -->

	<!-- Start Product Area -->
	<div class="product-area section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>Trending Item</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="product-info">
						<div class="nav-main">
							<!-- Tab Nav -->
							<ul class="nav nav-tabs" id="myTab" role="tablist">
								<li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#man"
										role="tab">Man</a></li>
								<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#women"
										role="tab">Woman</a></li>
								<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#kids"
										role="tab">Kids</a></li>
								<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#accessories"
										role="tab">Accessories</a></li>
								<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#essential"
										role="tab">Essential</a></li>
								<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#prices"
										role="tab">Prices</a></li>
							</ul>
							<!--/ End Tab Nav -->
						</div>
						<div class="tab-content" id="myTabContent">
							<!-- Start Single Tab -->
							<div class="tab-pane fade show active" id="man" role="tabpanel">
								<div class="tab-single">
									<div class="row">
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<!-- <img class="default-img"
															src="https://via.placeholder.com/550x750" alt="#"> -->
														<!-- <img class="hover-img" src="https://via.placeholder.com/550x750"
															alt="#"> -->
														<img class="default-img" src="images/550/1.jpg"
															alt="#" >
														<img class="hover-img" src="images/550/1.jpg"
															alt="#" >
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Hot Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/2.jpg" alt="#">
														<img class="hover-img" src="images/550/2.jpg"
															alt="#">
														<span class="promo">Promo</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Pink Show</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<!-- <img class="default-img"
															src="https://via.placeholder.com/550x750" alt="#">
														<img class="hover-img" src="https://via.placeholder.com/550x750"
															alt="#"> -->
														<img class="default-img"
															src="images/550/3.jpg" alt="#">
														<img class="hover-img" src="images/550/3.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<!-- <img class="default-img"
															src="https://via.placeholder.com/550x750" alt="#">
														<img class="hover-img" src="https://via.placeholder.com/550x750"
															alt="#"> -->
														<img class="default-img"
															src="images/550/4.jpg" alt="#">
														<img class="hover-img" src="images/550/4.jpg"
															alt="#">
														<span class="new">New</span>
														<span class="price-dec-2">Discount</span>
														<span class="out-of-stock">New</span>
														<span class="promo">
															promo
														</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Pant Collectons</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/5.jpg" alt="#">
														<img class="hover-img" src="images/550/5.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/6.jpg" alt="#">
														<img class="hover-img" src="images/550/6.jpg"
															alt="#">
														<span class="price-dec">30% Off</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Cap For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/7.jpg" alt="#">
														<img class="hover-img" src="images/550/7.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Polo Dress For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/8.jpg" alt="#">
														<img class="hover-img" src="images/550/8.jpg"
															alt="#">
														<span class="out-of-stock">Hot</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Black Sunglass For Women</a></h3>
													<div class="product-price">
														<span class="old">$60.00</span>
														<span>$50.00</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--/ End Single Tab -->
							<!-- Start Single Tab -->
							<div class="tab-pane fade" id="women" role="tabpanel">
								<div class="tab-single">
									<div class="row">
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/9.jpg" alt="#">
														<img class="hover-img" src="images/550/9.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Hot Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/10.jpg" alt="#">
														<img class="hover-img" src="images/550/10.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Pink Show</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/11.jpg" alt="#">
														<img class="hover-img" src="images/550/11.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/12.jpg" alt="#">
														<img class="hover-img" src="images/550/12.jpg"
															alt="#">
														<span class="new">New</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Pant Collectons</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/13.jpg" alt="#">
														<img class="hover-img" src="images/550/13.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/14.jpg" alt="#">
														<img class="hover-img" src="images/550/14.jpg"
															alt="#">
														<span class="price-dec">30% Off</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Cap For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/15.jpg" alt="#">
														<img class="hover-img" src="images/550/15.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Polo Dress For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/16.jpg" alt="#">
														<img class="hover-img" src="images/550/16.jpg"
															alt="#">
														<span class="out-of-stock">Hot</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Black Sunglass For Women</a></h3>
													<div class="product-price">
														<span class="old">$60.00</span>
														<span>$50.00</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--/ End Single Tab -->
							<!-- Start Single Tab -->
							<div class="tab-pane fade" id="kids" role="tabpanel">
								<div class="tab-single">
									<div class="row">
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/17.jpg" alt="#">
														<img class="hover-img" src="images/550/17.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Hot Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/18.jpg" alt="#">
														<img class="hover-img" src="images/550/18.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Pink Show</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/19.jpg" alt="#">
														<img class="hover-img" src="images/550/19.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/20.jpg" alt="#">
														<img class="hover-img" src="images/550/20.jpg"
															alt="#">
														<span class="new">New</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Pant Collectons</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/21.jpg" alt="#">
														<img class="hover-img" src="images/550/21.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/22.jpg" alt="#">
														<img class="hover-img" src="images/550/22.jpg"
															alt="#">
														<span class="price-dec">30% Off</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Cap For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/23.jpg" alt="#">
														<img class="hover-img" src="images/550/23.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Polo Dress For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/24.jpg" alt="#">
														<img class="hover-img" src="images/550/24.jpg"
															alt="#">
														<span class="out-of-stock">Hot</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Black Sunglass For Women</a></h3>
													<div class="product-price">
														<span class="old">$60.00</span>
														<span>$50.00</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--/ End Single Tab -->
							<!-- Start Single Tab -->
							<div class="tab-pane fade" id="accessories" role="tabpanel">
								<div class="tab-single">
									<div class="row">
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/25.jpg" alt="#">
														<img class="hover-img" src="images/550/25.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Hot Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/26.jpg" alt="#">
														<img class="hover-img" src="images/550/26.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Pink Show</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/27.jpg" alt="#">
														<img class="hover-img" src="images/550/27.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/28.jpg" alt="#">
														<img class="hover-img" src="images/550/28.jpg"
															alt="#">
														<span class="new">New</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Pant Collectons</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/29.jpg" alt="#">
														<img class="hover-img" src="images/550/29.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/30.jpg" alt="#">
														<img class="hover-img" src="images/550/30.jpg"
															alt="#">
														<span class="price-dec">30% Off</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Cap For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/31.jpg" alt="#">
														<img class="hover-img" src="images/550/31.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Polo Dress For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/32.jpg" alt="#">
														<img class="hover-img" src="images/550/32.jpg"
															alt="#">
														<span class="out-of-stock">Hot</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Black Sunglass For Women</a></h3>
													<div class="product-price">
														<span class="old">$60.00</span>
														<span>$50.00</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--/ End Single Tab -->
							<!-- Start Single Tab -->
							<div class="tab-pane fade" id="essential" role="tabpanel">
								<div class="tab-single">
									<div class="row">
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/33.jpg" alt="#">
														<img class="hover-img" src="images/550/33.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Hot Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/34.jpg" alt="#">
														<img class="hover-img" src="images/550/34.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Pink Show</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/35.jpg" alt="#">
														<img class="hover-img" src="images/550/35.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/36.jpg" alt="#">
														<img class="hover-img" src="images/550/36.jpg"
															alt="#">
														<span class="new">New</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Pant Collectons</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/37.jpg" alt="#">
														<img class="hover-img" src="images/550/37.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/38.jpg" alt="#">
														<img class="hover-img" src="images/550/38.jpg"
															alt="#">
														<span class="price-dec">30% Off</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Cap For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/39.jpg" alt="#">
														<img class="hover-img" src="images/550/39.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Polo Dress For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/40.jpg" alt="#">
														<img class="hover-img" src="images/550/40.jpg"
															alt="#">
														<span class="out-of-stock">Hot</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Black Sunglass For Women</a></h3>
													<div class="product-price">
														<span class="old">$60.00</span>
														<span>$50.00</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--/ End Single Tab -->
							<!-- Start Single Tab -->
							<div class="tab-pane fade" id="prices" role="tabpanel">
								<div class="tab-single">
									<div class="row">
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/41.jpg" alt="#">
														<img class="hover-img" src="images/550/41.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Hot Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/42.jpg" alt="#">
														<img class="hover-img" src="images/550/42.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Pink Show</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/43.jpg" alt="#">
														<img class="hover-img" src="images/550/43.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/44.jpg" alt="#">
														<img class="hover-img" src="images/550/44.jpg"
															alt="#">
														<span class="new">New</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Women Pant Collectons</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/45.jpg" alt="#">
														<img class="hover-img" src="images/550/45.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/46.jpg" alt="#">
														<img class="hover-img" src="images/550/46.jpg"
															alt="#">
														<span class="price-dec">30% Off</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Awesome Cap For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/47.jpg" alt="#">
														<img class="hover-img" src="images/550/47.jpg"
															alt="#">
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Polo Dress For Women</a></h3>
													<div class="product-price">
														<span>$29.00</span>
													</div>
												</div>
											</div>
										</div>
										<div class="col-xl-3 col-lg-4 col-md-4 col-12">
											<div class="single-product">
												<div class="product-img">
													<a href="product-details.html">
														<img class="default-img"
															src="images/550/48.jpg" alt="#">
														<img class="hover-img" src="images/550/48.jpg"
															alt="#">
														<span class="out-of-stock">Hot</span>
													</a>
													<div class="button-head">
														<div class="product-action">
															<a data-toggle="modal" data-target="#exampleModal"
																title="Quick View" href="#"><i
																	class=" ti-eye"></i><span>Quick Shop</span></a>
															<a title="Wishlist" href="#"><i
																	class=" ti-heart "></i><span>Add to
																	Wishlist</span></a>
															<a title="Compare" href="#"><i
																	class="ti-bar-chart-alt"></i><span>Add to
																	Compare</span></a>
														</div>
														<div class="product-action-2">
															<a title="Add to cart" href="#">Add to cart</a>
														</div>
													</div>
												</div>
												<div class="product-content">
													<h3><a href="product-details.html">Black Sunglass For Women</a></h3>
													<div class="product-price">
														<span class="old">$60.00</span>
														<span>$50.00</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<!--/ End Single Tab -->
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Product Area -->

	<!-- Start Midium Banner  -->
	<section class="midium-banner">
		<div class="container">
			<div class="row">
				<!-- Single Banner  -->
				<div class="col-lg-6 col-md-6 col-12">
					<div class="single-banner">
						<img src="images/600/4.jpg" alt="#">
						<div class="content">
							<p>Olay Collectons</p>
							<h3>Olay Pack <br>Up to<span> 50%</span></h3>
							<a href="#">Shop Now</a>
						</div>
					</div>
				</div>
				<!-- /End Single Banner  -->
				<!-- Single Banner  -->
				<div class="col-lg-6 col-md-6 col-12">
					<div class="single-banner">
						<img src="images/600/5.jpg" alt="#">
						<div class="content">
							<p>Skincare Essential</p>
							<h3>mid season <br> up to <span>70%</span></h3>
							<a href="#" class="btn">Shop Now</a>
						</div>
					</div>
				</div>
				<!-- /End Single Banner  -->
			</div>
		</div>
	</section>
	<!-- End Midium Banner -->

	<!-- Start Most Popular -->
	<div class="product-area most-popular section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>Hot Item</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-12">
					<div class="owl-carousel popular-slider">
						<!-- Start Single Product -->
						<div class="single-product">
							<div class="product-img">
								<a href="product-details.html">
									<img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
									<img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
									<span class="out-of-stock">Hot</span>
								</a>
								<div class="button-head">
									<div class="product-action">
										<a data-toggle="modal" data-target="#exampleModal" title="Quick View"
											href="#"><i class=" ti-eye"></i><span>Quick Shop</span></a>
										<a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to
												Wishlist</span></a>
										<a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to
												Compare</span></a>
									</div>
									<div class="product-action-2">
										<a title="Add to cart" href="#">Add to cart</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<h3><a href="product-details.html">Black Sunglass For Women</a></h3>
								<div class="product-price">
									<span class="old">$60.00</span>
									<span>$50.00</span>
								</div>
							</div>
						</div>
						<!-- End Single Product -->
						<!-- Start Single Product -->
						<div class="single-product">
							<div class="product-img">
								<a href="product-details.html">
									<img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
									<img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
								</a>
								<div class="button-head">
									<div class="product-action">
										<a data-toggle="modal" data-target="#exampleModal" title="Quick View"
											href="#"><i class=" ti-eye"></i><span>Quick Shop</span></a>
										<a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to
												Wishlist</span></a>
										<a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to
												Compare</span></a>
									</div>
									<div class="product-action-2">
										<a title="Add to cart" href="#">Add to cart</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<h3><a href="product-details.html">Women Hot Collection</a></h3>
								<div class="product-price">
									<span>$50.00</span>
								</div>
							</div>
						</div>
						<!-- End Single Product -->
						<!-- Start Single Product -->
						<div class="single-product">
							<div class="product-img">
								<a href="product-details.html">
									<img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
									<img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
									<span class="new">New</span>
								</a>
								<div class="button-head">
									<div class="product-action">
										<a data-toggle="modal" data-target="#exampleModal" title="Quick View"
											href="#"><i class=" ti-eye"></i><span>Quick Shop</span></a>
										<a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to
												Wishlist</span></a>
										<a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to
												Compare</span></a>
									</div>
									<div class="product-action-2">
										<a title="Add to cart" href="#">Add to cart</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<h3><a href="product-details.html">Awesome Pink Show</a></h3>
								<div class="product-price">
									<span>$50.00</span>
								</div>
							</div>
						</div>
						<!-- End Single Product -->
						<!-- Start Single Product -->
						<div class="single-product">
							<div class="product-img">
								<a href="product-details.html">
									<img class="default-img" src="https://via.placeholder.com/550x750" alt="#">
									<img class="hover-img" src="https://via.placeholder.com/550x750" alt="#">
								</a>
								<div class="button-head">
									<div class="product-action">
										<a data-toggle="modal" data-target="#exampleModal" title="Quick View"
											href="#"><i class=" ti-eye"></i><span>Quick Shop</span></a>
										<a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Add to
												Wishlist</span></a>
										<a title="Compare" href="#"><i class="ti-bar-chart-alt"></i><span>Add to
												Compare</span></a>
									</div>
									<div class="product-action-2">
										<a title="Add to cart" href="#">Add to cart</a>
									</div>
								</div>
							</div>
							<div class="product-content">
								<h3><a href="product-details.html">Awesome Bags Collection</a></h3>
								<div class="product-price">
									<span>$50.00</span>
								</div>
							</div>
						</div>
						<!-- End Single Product -->
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Most Popular Area -->

	<section class="section free-version-banner">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-md-8 offset-md-2 col-xs-12">
					<div class="section-title mb-60">
						<span class="text-white wow fadeInDown" data-wow-delay=".2s"
							style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInDown;">Eshop Free
							Lite version</span>
						<h2 class="text-white wow fadeInUp" data-wow-delay=".4s"
							style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">Currently You
							are using free<br> lite Version of Eshop.</h2>
						<p class="text-white wow fadeInUp" data-wow-delay=".6s"
							style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">Please,
							purchase full version of the template to get all pages,<br> features and commercial license.
						</p>

						<div class="button">
							<a href="https://wpthemesgrid.com/downloads/eshop-ecommerce-html5-template/" target="_blank"
								rel="nofollow" class="btn wow fadeInUp" data-wow-delay=".8s">Purchase Now</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<!-- Start Shop Home List  -->
	<section class="shop-home-list section">
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-6 col-12">
					<div class="row">
						<div class="col-12">
							<div class="shop-section-title">
								<h1>On sale</h1>
							</div>
						</div>
					</div>
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/1.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h4 class="title"><a href="#">Licity jelly leg flat Sandals</a></h4>
									<p class="price with-discount">$59</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/2.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$44</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/3.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$89</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="row">
						<div class="col-12">
							<div class="shop-section-title">
								<h1>Best Seller</h1>
							</div>
						</div>
					</div>
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/4.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$65</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/5.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$33</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/6.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$77</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="row">
						<div class="col-12">
							<div class="shop-section-title">
								<h1>Top viewed</h1>
							</div>
						</div>
					</div>
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/7.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$22</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/8.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$35</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
					<!-- Start Single List  -->
					<div class="single-list">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-12">
								<div class="list-image overlay">
									<img src="images/115/9.jpg" alt="#">
									<a href="#" class="buy"><i class="fa fa-shopping-bag"></i></a>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-12 no-padding">
								<div class="content">
									<h5 class="title"><a href="#">Licity jelly leg flat Sandals</a></h5>
									<p class="price with-discount">$99</p>
								</div>
							</div>
						</div>
					</div>
					<!-- End Single List  -->
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Home List  -->

	<!-- Start Shop Blog  -->
	<section class="shop-blog section">
		<div class="container">
			<div class="row">
				<div class="col-12">
					<div class="section-title">
						<h2>From Our Blog</h2>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 col-12">
					<!-- Start Single Blog  -->
					<div class="shop-single-blog">
						<img src="images/370/1.jpg" alt="#">
						<div class="content">
							<p class="date">22 July , 2020. Monday</p>
							<a href="#" class="title">Face Mask Granier.</a>
							<a href="#" class="more-btn">Continue Reading</a>
						</div>
					</div>
					<!-- End Single Blog  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<!-- Start Single Blog  -->
					<div class="shop-single-blog">
						<img src="images/370/2.jpg" alt="#">
						<div class="content">
							<p class="date">22 July, 2020. Monday</p>
							<a href="#" class="title">Man’s Product Winter Sale</a>
							<a href="#" class="more-btn">Continue Reading</a>
						</div>
					</div>
					<!-- End Single Blog  -->
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<!-- Start Single Blog  -->
					<div class="shop-single-blog">
						<img src="images/370/3.jpg" alt="#">
						<div class="content">
							<p class="date">22 July, 2020. Monday</p>
							<a href="#" class="title">Sun Protection</a>
							<a href="#" class="more-btn">Continue Reading</a>
						</div>
					</div>
					<!-- End Single Blog  -->
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Blog  -->

	<!-- Start Shop Services Area -->
	<section class="shop-services section home">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-rocket"></i>
						<h4>Free shiping</h4>
						<p>Orders over $100</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-reload"></i>
						<h4>Free Return</h4>
						<p>Within 30 days returns</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-lock"></i>
						<h4>Sucure Payment</h4>
						<p>100% secure payment</p>
					</div>
					<!-- End Single Service -->
				</div>
				<div class="col-lg-3 col-md-6 col-12">
					<!-- Start Single Service -->
					<div class="single-service">
						<i class="ti-tag"></i>
						<h4>Best Peice</h4>
						<p>Guaranteed price</p>
					</div>
					<!-- End Single Service -->
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Services Area -->

	<!-- Start Shop Newsletter  -->
	<section class="shop-newsletter section">
		<div class="container">
			<div class="inner-top">
				<div class="row">
					<div class="col-lg-8 offset-lg-2 col-12">
						<!-- Start Newsletter Inner -->
						<div class="inner">
							<h4>Newsletter</h4>
							<p> Subscribe to our newsletter and get <span>10%</span> off your first purchase</p>
							<form action="mail/mail.php" method="get" target="_blank" class="newsletter-inner">
								<input name="EMAIL" placeholder="Your email address" required="" type="email">
								<button class="btn">Subscribe</button>
							</form>
						</div>
						<!-- End Newsletter Inner -->
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- End Shop Newsletter -->

	<!-- Modal -->
	<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span class="ti-close"
							aria-hidden="true"></span></button>
				</div>
				<div class="modal-body">
					<div class="row no-gutters">
						<div class="col-lg-6 offset-lg-3 col-12">
							<h4
								style="margin-top:100px;font-size:14px; font-weight:500; color:#F7941D; display:block; margin-bottom:5px;">
								Eshop Free Lite</h4>
							<h3 style="font-size:30px;color:#333;">Currently You are using free lite Version of Eshop.
							</h3>
							<p style="display:block; margin-top:20px; color:#888; font-size:14px; font-weight:400;">
								Please, purchase full version of the template to get all pages, features and commercial
								license</p>
							<div class="button" style="margin-top:30px;">
								<a href="https://wpthemesgrid.com/downloads/eshop-ecommerce-html5-template/"
									target="_blank" class="btn" style="color:#fff;">Buy Now!</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal end -->

	<!-- Start Footer Area -->
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>