<template>
  <footer class="footer">
		<!-- Footer Top -->
		<div class="footer-top section">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 col-md-6 col-12">
						<!-- Single Widget -->
						<div class="single-footer about">
							<div class="logo">
								<router-link to="/"><img src="images/logo/1.jpg" alt="#"></router-link>
								<!-- <a href="index.html"><img src="images/logo2.png" alt="#"></a> -->
							</div>
							<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3957.2205569514417!2d112.69274392835857!3d-7.329107746573339!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2dd7fdbf605ffd45%3A0x3539f29c220a23cb!2sGrand%20Harvest%2C%20Cluster%20Caspia%2C%20CD%2020!5e0!3m2!1sid!2sid!4v1628826753717!5m2!1sid!2sid" width="350" height="175" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
							<!-- <p class="call">Got Question? Call us 24/7<span><a href="tel:123456789">+0123 456
										789</a></span></p> -->
										<!-- Single Widget -->
						<div class="single-footer social call">
							<!-- <h4>Get In Tuch</h4> -->
							<!-- Single Widget -->
							<div class="contact">
								<ul>
									<li>Soho Harvest One no. 3, Perumahan Grand Harvest</li>
									<li>info@ab2.co.id | cs@ab2.co.id</li>
									<li><b>Telp:</b> 031-99754722</li>
									<li><b>WhatsApp:</b> +6282141833945</li>
								</ul>
							</div>
							<!-- End Single Widget -->
							<ul>
								<li><a href="#"><i class="ti-facebook"></i></a></li>
								<li><a href="#"><i class="ti-twitter"></i></a></li>
								<li><a href="#"><i class="ti-flickr"></i></a></li>
								<li><a href="#"><i class="ti-instagram"></i></a></li>
							</ul>
						</div>
						<!-- End Single Widget -->

						</div>
						<!-- End Single Widget -->
					</div>
					<div class="col-lg-8 col-md-6 col-12">
						<div class="row">
							<div class="col-lg-4 col-md-6 col-12">
								<!-- Single Widget -->
								<div class="single-footer links">
									<h4>Information</h4>
									<ul>
										<li>
											<router-link to="/faq">FAQ</router-link>
										</li>
										<li>
											<router-link to="/contact">Contact Us</router-link>
										</li>
										<li>
											<router-link to="/affiliate">Affiliate</router-link>
										</li>
									</ul>
								</div>
								<!-- End Single Widget -->
							</div>
							<div class="col-lg-4 col-md-6 col-12">
								<!-- Single Widget -->
								<div class="single-footer links">
									<h4>Customer Service</h4>
									<ul>	
										<li>
											<router-link to="/payment-method">Payment Methods</router-link>
										</li>
										<li>
											<router-link to="/shipping">Shipping</router-link>
										</li>
									</ul>
								</div>
							</div>
							<div class="col-lg-4 col-md-6 col-12">
								<div class="single-footer social">
									<h4>Account</h4>
									<div class="contact">
										<ul>
											<li>
												<router-link to="/login">Login</router-link>
											</li>
											<li>
												<router-link to="/register">Register</router-link>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<div class="row mt-4">
							<div class="col-lg-8 col-md-6 col-12">
								<div class="single-footer ">
									<h4 class="mb-4">Nearest Branch</h4>
									<div class="row">
										<div class="col-auto">
											<div class="d-flex mb-3">
												<div class="col-3 p-0">
													<img class="brand-img img-fluid rounded" src="images/brand-icon/1.jpg" alt="brand">
												</div>
												<div class="col-auto">
													<p class="text-white font-weight-bold">WARDAH</p>
													<p>Kecamatan, Surabaya</p>
												</div>
											</div>
											<div class="d-flex mb-3">
												<div class="col-3 p-0">
													<img class="brand-img img-fluid rounded" src="images/brand-icon/1.jpg" alt="brand">
												</div>
												<div class="col-auto">
													<p class="text-white font-weight-bold">WARDAH</p>
													<p>Kecamatan, Surabaya</p>
												</div>
											</div>
											<div class="d-flex mb-3">
												<div class="col-3 p-0">
													<img class="brand-img img-fluid rounded" src="images/brand-icon/1.jpg" alt="brand">
												</div>
												<div class="col-auto">
													<p class="text-white font-weight-bold">WARDAH</p>
													<p>Kecamatan, Surabaya</p>
												</div>
											</div>
										</div>
										<div class="col-auto">
											<div class="d-flex mb-3">
												<div class="col-3 p-0">
													<img class="brand-img img-fluid rounded" src="images/brand-icon/1.jpg" alt="brand">
												</div>
												<div class="col-auto">
													<p class="text-white font-weight-bold">WARDAH</p>
													<p>Kecamatan, Surabaya</p>
												</div>
											</div>
											<div class="d-flex mb-3">
												<div class="col-3 p-0">
													<img class="brand-img img-fluid rounded" src="images/brand-icon/1.jpg" alt="brand">
												</div>
												<div class="col-auto">
													<p class="text-white font-weight-bold">WARDAH</p>
													<p>Kecamatan, Surabaya</p>
												</div>
											</div>
											<div class="d-flex mb-3">
												<div class="col-3 p-0">
													<img class="brand-img img-fluid rounded" src="images/brand-icon/1.jpg" alt="brand">
												</div>
												<div class="col-auto">
													<p class="text-white font-weight-bold">WARDAH</p>
													<p>Kecamatan, Surabaya</p>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					
				</div>
			</div>
		</div>
		<!-- End Footer Top -->
		<div class="copyright">
			<div class="container">
				<div class="inner">
					<div class="row">
						<div class="col-lg-6 col-12">
							<div class="left">
								<p>Copyright © 2020 <a href="http://www.wpthemesgrid.com"
										target="_blank">Wpthemesgrid</a> - All Rights Reserved.</p>
							</div>
						</div>
						<div class="col-lg-6 col-12">
							<div class="right">
								<img src="assets/images/payments.png" alt="#">
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
</template>

<script>
export default {

}
</script>

<style>

</style>