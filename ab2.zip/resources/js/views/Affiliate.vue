<template>
  <h1>
      AFFILIATE PAGE IS ON PROGRESS
  </h1>
</template>

<script>
export default { 

}
</script> 

<style>

</style>