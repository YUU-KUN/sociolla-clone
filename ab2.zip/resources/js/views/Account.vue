<template>
  <h1>
      ACCOUNT PAGE IS ON PROGRESS
  </h1>
</template>

<script>
export default {

}
</script>

<style>

</style>